import { copyFile, mkdir } from 'node:fs/promises';
import { join } from 'node:path';

const output = 'dist';
const files = ['index.html', 'styles.css', 'app.js', 'icon.svg'];

await mkdir(output, { recursive: true });
for (const file of files) {
  await copyFile(file, join(output, file));
}
